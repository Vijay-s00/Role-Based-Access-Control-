import React, { useState } from "react";

const AddRoleForm = ({ addRole }) => {
  const [roleName, setRoleName] = useState("");
  const [permissions, setPermissions] = useState("");
  const [error, setError] = useState(""); // State to store error messages

  const handleSubmit = (e) => {
    e.preventDefault();

    // Clear any previous error
    setError("");

    // Validate role name (only alphabetic characters, spaces, and hyphens allowed)
    const roleNameRegex = /^[A-Za-z\s-]+$/;
    if (!roleName.trim()) {
      setError("Role name is required.");
      return;
    }
    if (!roleNameRegex.test(roleName)) {
      setError("Role name can only contain letters, spaces, and hyphens.");
      return;
    }

    // Validate permissions (must not be empty and must be a valid comma-separated list)
    if (!permissions.trim()) {
      setError("Permissions are required.");
      return;
    }

    // Convert permissions into an array and validate format (non-empty, only alphabetic)
    const permissionsArray = permissions
      .split(",")
      .map((permission) => permission.trim())
      .filter((permission) => permission); // Remove empty permissions

    // Validate permissions (must contain valid characters, letters only)
    const permissionRegex = /^[A-Za-z]+$/;
    for (let perm of permissionsArray) {
      if (!permissionRegex.test(perm)) {
        setError(`Invalid permission: "${perm}". Permissions should only contain letters.`);
        return;
      }
    }

    if (permissionsArray.length === 0) {
      setError("At least one permission is required.");
      return;
    }

    // If no errors, add the role
    addRole(roleName, permissionsArray.join(", "));

    // Clear the form fields after adding the role
    setRoleName("");
    setPermissions("");
  };

  return (
    <div>
      <h3>Add New Role</h3>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Role Name:</label>
          <input
            type="text"
            value={roleName}
            onChange={(e) => setRoleName(e.target.value)}
            placeholder="Enter role name"
            required
          />
        </div>
        <div>
          <label>Permissions:</label>
          <input
            type="text"
            value={permissions}
            onChange={(e) => setPermissions(e.target.value)}
            placeholder="Enter permissions, separated by commas (e.g., read, write)"
            required
          />
        </div>

        {error && <p style={{ color: "red" }}>{error}</p>} {/* Display error message */}

        <button type="submit">Add Role</button>
      </form>
    </div>
  );
};

export default AddRoleForm;
