import React, { useState } from "react";
import "./App.css";
import Usertable from "./Usertable";
import AddUserForm from "./AddUserForm";
import Roletable from "./Roletable";
import AddRoleForm from "./AddRoleForm";

// Mock data for roles
const initialRoles = [
  { id: 1, name: "Admin", permissions: ["Read", "Write", "Delete"] },
  { id: 2, name: "Editor", permissions: ["Read", "Write"] },
  { id: 3, name: "Viewer", permissions: ["Read"] },
];

function App() {
  const [users, setUsers] = useState([]);
  const [roles, setRoles] = useState(initialRoles);
  const [userSearch, setUserSearch] = useState(""); // User filtering state

  // Handle adding a user
  const addUser = (name, role) => {
    const newUser = { id: Date.now(), name, role, status: "Active" };
    setUsers([...users, newUser]);
  };

  // Handle editing a user
  const editUser = (id, newRole, newStatus) => {
    setUsers(
      users.map((user) =>
        user.id === id ? { ...user, role: newRole, status: newStatus } : user
      )
    );
  };

  // Handle deleting a user
  const deleteUser = (id) => {
    setUsers(users.filter((user) => user.id !== id));
  };

  // Handle adding a role
  const addRole = (roleName, permissions) => {
    const newRole = {
      id: Date.now(),
      name: roleName,
      permissions: permissions.split(",").map((p) => p.trim()),
    };
    setRoles([...roles, newRole]);
  };

  // Handle editing a role's permissions
  const editRolePermissions = (id, newPermissions) => {
    setRoles(
      roles.map((role) =>
        role.id === id
          ? {
              ...role,
              permissions: newPermissions
                ? newPermissions.split(",").map((p) => p.trim())
                : role.permissions, // Keep original permissions if newPermissions is invalid
            }
          : role
      )
    );
  };

  // Handle deleting a role
  const deleteRole = (id) => {
    setRoles(roles.filter((role) => role.id !== id));
  };

  // Filter users based on the search input
  const filteredUsers = users.filter((user) =>
    user.name.toLowerCase().includes(userSearch.toLowerCase())
  );

  return (
    <div className="App">
      <h1>RBAC User & Role Management</h1>

      {/* User Management */}
      <div>
        <h2>User Management</h2>
        <div className="filters">
          <input
            type="text"
            placeholder="Search Users by Name"
            value={userSearch}
            onChange={(e) => setUserSearch(e.target.value)}
          />
        </div>
        <Usertable
          users={filteredUsers}
          roles={roles}
          editUser={editUser}
          deleteUser={deleteUser}
        />
        <AddUserForm roles={roles} addUser={addUser} />
      </div>

      {/* Role Management */}
      <div>
        <h2>Role Management</h2>
        <Roletable
          roles={roles}
          editRolePermissions={editRolePermissions}
          deleteRole={deleteRole}
        />
        <AddRoleForm addRole={addRole} />
      </div>
    </div>
  );
}

export default App;
