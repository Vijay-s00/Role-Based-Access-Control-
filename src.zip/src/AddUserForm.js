import React, { useState } from "react";

const AddUserForm = ({ roles, addUser }) => {
  const [name, setName] = useState("");
  const [role, setRole] = useState(roles[0]?.name || "");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (name && role) {
      addUser(name, role);
      setName("");
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Enter user name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
      />
      <select value={role} onChange={(e) => setRole(e.target.value)} required>
        {roles.map(role => (
          <option key={role.id} value={role.name}>{role.name}</option>
        ))}
      </select>
      <button type="submit">Add User</button>
    </form>
  );
};

export default AddUserForm;
