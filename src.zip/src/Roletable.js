import React from "react";

const RoleTable = ({ roles, editRolePermissions, deleteRole }) => {
  return (
    <table>
      <thead>
        <tr>
          <th>Role</th>
          <th>Permissions</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {roles.map(role => (
          <tr key={role.id}>
            <td>{role.name}</td>
            <td>{role.permissions.join(", ")}</td>
            <td>
              <button onClick={() => editRolePermissions(role.id, prompt("Enter new permissions (comma separated):", role.permissions.join(", ")))}>Edit Permissions</button>
              <button onClick={() => deleteRole(role.id)}>Delete Role</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default RoleTable;
